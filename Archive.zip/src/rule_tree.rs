pub mod matcher;
pub mod parsing;
pub mod types;

pub use types::{ArrivalInfo, Hour, IPError, IpGlobbable, IpVer, Octet, Port, Protocol, Weekday};

use derive_more::{Debug, Display, Error, PartialEq};

use crate::rule_tree::matcher::Match;
pub use matcher::MatchBuilder;

#[derive(Clone, Debug)]
pub struct RuleTree {
    name: String,
    description: String,
    pub head: Match,
}

impl RuleTree {
    pub fn new(name: String, description: String, head: Match) -> Self {
        Self {
            name,
            description,
            head,
        }
    }
}

impl std::fmt::Display for RuleTree {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(
            f,
            "RuleTree: {}, description: {}",
            self.name, self.description
        )
    }
}

#[derive(PartialEq, Debug, Clone)]
struct Arm {
    pattern: Pattern,
    into: ArmEnd,
}

#[derive(PartialEq, Debug, Clone)]
pub enum ArmEnd {
    Verdict(Verdict),
    Match(Match),
}

#[derive(Debug, Clone, PartialEq, Display)]
pub enum Verdict {
    Allow,
    Drop,
    AllowWarn(String),
    DropWarn(String),
}

#[derive(Debug, Display, Clone, PartialEq)]
pub enum Pattern {
    // TODO: move equal into comparision or alternatively remove comparision entirely
    Equal(FieldValue),
    #[display("Patterns, count: {}", _0.len())]
    Or(Vec<Pattern>),
    #[display("Patterns, count: {}", _0.len())]
    And(Vec<Pattern>),

    #[display("Comparing with {}, to {}", _0, _1)]
    Comparison(Operation, FieldValue),
    Wildcard,
}

#[derive(Debug, Display, Clone, Copy, PartialEq)]
pub enum FieldValue {
    Ip(IpGlobbable),
    IpVer(IpVer),
    DayOfWeek(Weekday),
    Hour(Hour),
    Protocol(Protocol),
    Port(Port),
}

#[derive(Debug, Display, Clone, Copy, PartialEq)]
pub enum MatchKind {
    SrcIp,
    DstIp,
    IpVer,
    DayOfWeek,
    Hour,
    Protocol,
    SrcPort,
    DstPort,
}

#[derive(Debug, Display, Clone, Copy, PartialEq, Eq)]
pub enum Operation {
    Greater,
    Lesser,
    GreaterOrEqual,
    LesserOrEqual,
}

impl Pattern {
    #[allow(clippy::match_same_arms)]
    fn validate_for(&self, kind: &MatchKind) -> Result<(), RuleError> {
        match (self, kind) {
            (Pattern::Wildcard, _) => Ok(()),

            (Pattern::Equal(_), _) => Ok(()),
            (
                Pattern::Comparison(..),
                MatchKind::SrcPort | MatchKind::DstPort | MatchKind::Hour | MatchKind::DayOfWeek,
            ) => Ok(()),
            (Pattern::Comparison(..), _) => Err(RuleError::InvalidPattern(self.clone())),

            (Pattern::Or(patterns) | Pattern::And(patterns), _) => {
                for pattern in patterns {
                    pattern.validate_for(kind)?;
                }
                Ok(())
            } // (Pattern::Or(_), _) => Err(RuleError::InvalidPattern(self.clone())),
        }
    }
}

pub enum Step<'a> {
    NeedsMatch {
        kind: &'a MatchKind,
        pattern: &'a Pattern,
    },
    Verdict(&'a Verdict),
    NoMatch,
}

pub struct TreeWalker<'a> {
    current: &'a Match,
    arm_index: usize,
}

impl<'a> TreeWalker<'a> {
    pub fn new(tree: &'a RuleTree) -> Self {
        Self {
            current: &tree.head,
            arm_index: 0,
        }
    }

    pub fn current_step(&self) -> Step<'a> {
        match self.current.arms().get(self.arm_index) {
            Some(arm) => Step::NeedsMatch {
                kind: self.current.kind(),
                pattern: &arm.pattern,
            },
            None => Step::NoMatch,
        }
    }

    pub fn advance(&mut self, matched: bool) -> Step<'a> {
        let arm = &self.current.arms()[self.arm_index];

        if matched {
            match &arm.into {
                ArmEnd::Verdict(v) => Step::Verdict(v),
                ArmEnd::Match(next) => {
                    self.current = next;
                    self.arm_index = 0;
                    self.current_step()
                }
            }
        } else {
            self.arm_index += 1;
            self.current_step()
        }
    }
}

#[derive(Debug, Display, Error)]
pub enum RuleError {
    #[display("Invalid Pattern Error, pattern: {}", _0)]
    InvalidPattern(#[error(not(source))] Pattern),
}
#[cfg(test)]
mod tests {

    use super::*;

    fn dummy_ip() -> IpGlobbable {
        IpGlobbable::new([
            Octet::Value(10),
            Octet::Value(0),
            Octet::Value(0),
            Octet::Value(1),
        ])
    }

    #[test]
    fn comparison_invalid_for_ip_protocol_ipver() {
        let pat = Pattern::Comparison(Operation::Lesser, FieldValue::Port(80.into()));
        let invalid = [
            MatchKind::SrcIp,
            MatchKind::DstIp,
            MatchKind::IpVer,
            MatchKind::Protocol,
        ];
        for kind in invalid {
            assert!(
                pat.validate_for(&kind).is_err(),
                "Comparison should be invalid for {kind}"
            );
        }
    }

    // #[test]
    // fn or_invalid_for_port_kinds() {
    //     let pat = Pattern::Or(vec![Pattern::Equal(FieldValue::Port(80.into()))]);
    //     let invalid = [MatchKind::SrcPort, MatchKind::DstPort];
    //     for kind in invalid {
    //         assert!(
    //             pat.validate_for(&kind).is_err(),
    //             "Or should be invalid for {kind}"
    //         );
    //     }
    // }

    #[test]
    fn or_accepts_all_valid_nested_patterns_for_kind() {
        let pat = Pattern::Or(vec![
            Pattern::Equal(FieldValue::Protocol(Protocol::Tcp)),
            Pattern::Equal(FieldValue::Protocol(Protocol::Udp)),
        ]);

        assert!(
            pat.validate_for(&MatchKind::Protocol).is_ok(),
            "Or should accept valid nested patterns for Protocol"
        );
    }
}
